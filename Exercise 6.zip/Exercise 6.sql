use WorldEvents;

with EventsEra as (
select case when year(e.EventDate) < 1900 then
			'19th century and earlier'
			when year(e.EventDate) < 2000 then
			'20th century'
			else '21st century'
		end as Era,
		e.EventID
from tblEvent as e
)
select  Era, 
		count(*) as "Number Of Events"
from EventsEra
group by Era;
use DoctorWho;

with EpisodeInfo as (
select year(EpisodeDate) as EpisodeYear,
	   SeriesNumber,
	   EpisodeId
from tblEpisode
)
select *
from EpisodeInfo
pivot (
	count(EpisodeId)
for	
	SeriesNumber in ([1], [2], [3], [4], [5])
) as EpisodeYear;
use WorldEvents;

with ManyCountries as (
select cont.ContinentId,
	   count(countr.CountryId) as NumOfCountries
from tblContinent cont
join tblCountry countr
	on countr.ContinentID = cont.ContinentID
group by cont.ContinentId
having count(countr.CountryId) >= 3 
),
FewEvents as (
select cont.ContinentId,
	   count(ev.EventId) as NumOfEvents
from tblContinent cont
join tblCountry countr
	on countr.ContinentID = cont.ContinentID
join tblEvent ev
	on ev.CountryID = countr.CountryID
group by cont.ContinentId
having count(ev.EventId) <= 10 
)
select mc.ContinentID, c.ContinentName
from ManyCountries mc
join FewEvents fe
	on fe.ContinentID = mc.ContinentID
join tblContinent c
	on c.ContinentID = mc.ContinentID;